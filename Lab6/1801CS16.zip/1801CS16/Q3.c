/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 6
FileName : Q3.c
Problem Statement : Write a simple C program to calculate WT, TAT, the completion order using SRTF*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// driver code
int main(int argc, char const *argv[])
{
	// Input from user
	int n;
	printf("\nEnter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : \n");
	scanf("%d",&n);

	double avg_wt = 0, avg_tat = 0;

	if(n == 0){
		printf("\nAverage Waiting Time : %.2lf    Average Turnaround Time : %.2lf\n", avg_wt, avg_tat);
		printf("Completion order of Processes : \n");
		return 0;
	}

	int arrival_time[n], burst_time[n], rem_burst_time[n];

	for(int i=0;i<n;i++)
	{
		scanf("%d %d", &arrival_time[i], &burst_time[i]);

		if(arrival_time[i] < 0 || burst_time[i] < 0){
			printf("Usage : Input Only Non-negative Values for time\n");
			exit(1);
		}
		rem_burst_time[i] = burst_time[i];
	}

	// declare and initializ required arrays for storing times for each process
	int waiting_time[n], turnaround_time[n], completion_time[n], completion_order[n];
	memset(waiting_time, 0, sizeof(waiting_time));
	memset(turnaround_time, 0, sizeof(turnaround_time));
	memset(completion_time, -1, sizeof(completion_time));
	memset(completion_order, 0, sizeof(completion_order));

	// calculate completion time for each process
	int completed_cnt = 0;
	int t=0;
	int idx=0;
	while(1)
	{
		// On each iteration (time unit), select available and yet to complete process with min remaining burst time
		int curr_pid = -1, curr_min_bt = 1e9+5;
		for(int i=0;i<n;i++)
		{
			if(rem_burst_time[i] != 0 && arrival_time[i] <= t && rem_burst_time[i] < curr_min_bt)
			{
				curr_min_bt = rem_burst_time[i];
				curr_pid = i;
			}
		}

		// if no process satisfies the conditions, keep CPU idle for that time unit
		if(curr_pid == -1)
		{
			t++;
			continue;
		}

		rem_burst_time[curr_pid] -= 1;

		// Check for completion of process 
		if(rem_burst_time[curr_pid] == 0)
		{
			completed_cnt++;
			completion_time[curr_pid] = t+1;
			completion_order[idx] = curr_pid + 1;
			idx++;
		}

		t++;
		if(completed_cnt == n)
			break;
	}

	// calculate turnaround time for each process and average turnaround time
	for(int i=0;i<n;i++)
	{
		turnaround_time[i] = completion_time[i] - arrival_time[i];
		avg_tat += turnaround_time[i];
	}

	avg_tat /= (double)n;

	// calculate waiting time for each process and average waiting time
	for(int i=0;i<n;i++)
	{
		waiting_time[i] = turnaround_time[i] - burst_time[i];
		avg_wt += waiting_time[i];
	}

	avg_wt /= (double)n;

	// Output 
	printf("\nScheduing Algorithm Used : Shortest Remaining Time First (SRTF) (preemptive) \n");
	printf("\nAverage Waiting Time : %.2lf    Average Turnaround Time : %.2lf\n", avg_wt, avg_tat);
	printf("Completion order of Processes : ");
	for(int i=0;i<n;i++)
	{
		printf("P%d ", completion_order[i]);
	}
	printf("\n\n");

	// for(int i=0;i<n;i++)
	// {
	// 	printf("completion_time[%d] = %d, ", i, completion_time[i]);
	// }
	// printf("\n\n");

	// for(int i=0;i<n;i++)
	// {
	// 	printf("turnaround_time[%d] = %d, ", i, turnaround_time[i]);
	// }
	// printf("\n\n");

	// for(int i=0;i<n;i++)
	// {
	// 	printf("waiting_time[%d] = %d, ", i, waiting_time[i]);
	// }
	// printf("\n\n");


	return 0;
}
