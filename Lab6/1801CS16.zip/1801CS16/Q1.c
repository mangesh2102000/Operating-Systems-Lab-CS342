/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 6
FileName : Q1.c
Problem Statement : Write a simple C program to calculate WT, TAT, the completion order using FCFS*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// define struct to store process data
typedef struct Process{
	int pid;
	int at;		// at = arrival time
	int bt;		// bt = burst time
} process;

// comparator function for qsort
int compFunc(const void * a, const void * b)
{
	process p1 = *(process*)a;
	process p2 = *(process*)b;

	if(p1.at == p2.at){
		return (p1.pid > p2.pid);
	}
	else{
		return (p1.at > p2.at);
	}
}

int MIN(int a,int b){
	if(a < b)
		return a;
	return b;
}

int MAX(int a,int b){
	if(a < b)
		return b;
	return a;
}

// driver code
int main(int argc, char const *argv[])
{
	// Input from user
	int n;
	printf("\nEnter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : \n");
	scanf("%d",&n);

	double avg_wt = 0, avg_tat = 0;

	if(n == 0){
		printf("\nAverage Waiting Time : %.2lf    Average Turnaround Time : %.2lf\n", avg_wt, avg_tat);
		printf("Completion order of Processes : \n");
		return 0;
	}

	int arrival_time[n], burst_time[n];

	for(int i=0;i<n;i++)
	{
		scanf("%d %d", &arrival_time[i], &burst_time[i]);

		if(arrival_time[i] < 0 || burst_time[i] < 0){
			printf("Usage : Input Only Non-negative Values for time\n");
			exit(1);
		}
	}

	// store process data in struct array 
	process p[n];
	for(int i=0;i<n;i++)
	{	
		p[i].pid = i+1;
		p[i].at = arrival_time[i];
		p[i].bt = burst_time[i];
	}

	// sort processes according to their arrival time for FCFS scheduling
	qsort(p, n, sizeof(process), compFunc);

	// declare and initializ required arrays for storing times for each process
	int waiting_time[n], turnaround_time[n], completion_time[n];
	memset(waiting_time, 0, sizeof(waiting_time));
	memset(turnaround_time, 0, sizeof(turnaround_time));
	memset(completion_time, 0, sizeof(completion_time));

	// calculate completion time for each process
	int prev_completion_time = 0;
	for(int i=0;i<n;i++)
	{
		completion_time[p[i].pid-1] = p[i].at + MAX(0,prev_completion_time - p[i].at) + p[i].bt; 
		prev_completion_time = completion_time[p[i].pid-1];
	}

	// calculate turnaround time for each process and average turnaround time
	for(int i=0;i<n;i++)
	{
		turnaround_time[i] = completion_time[i] - arrival_time[i];
		avg_tat += turnaround_time[i];
	}

	avg_tat /= (double)n;

	// calculate waiting time for each process and average waiting time
	for(int i=0;i<n;i++)
	{
		waiting_time[i] = turnaround_time[i] - burst_time[i];
		avg_wt += waiting_time[i];
	}

	avg_wt /= (double)n;

	// Output 
	printf("\nScheduing Algorithm Used : First Come First Serve (FCFS) (non-preemptive) \n");
	printf("\nAverage Waiting Time : %.2lf    Average Turnaround Time : %.2lf\n", avg_wt, avg_tat);
	printf("Completion order of Processes : ");
	for(int i=0;i<n;i++)
	{
		printf("P%d ", p[i].pid);
	}
	printf("\n\n");

	// for(int i=0;i<n;i++)
	// {
	// 	printf("completion_time[%d] = %d, ", i, completion_time[i]);
	// }
	// printf("\n\n");

	// for(int i=0;i<n;i++)
	// {
	// 	printf("turnaround_time[%d] = %d, ", i, turnaround_time[i]);
	// }
	// printf("\n\n");

	// for(int i=0;i<n;i++)
	// {
	// 	printf("waiting_time[%d] = %d, ", i, waiting_time[i]);
	// }
	// printf("\n\n");

	return 0;
}
