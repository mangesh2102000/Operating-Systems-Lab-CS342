/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 6
FileName : Q2.c
Problem Statement : Write a simple C program to calculate WT, TAT, the completion order using SJF*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// define struct to store process data
typedef struct Process{
	int pid;
	int at;		// at = arrival time
	int bt;		// bt = burst time
} process;

// comparator function for qsort
int compFunc(const void * a, const void * b)
{
	process p1 = *(process*)a;
	process p2 = *(process*)b;

	if(p1.at == p2.at){
		if(p1.bt == p2.bt)
			return (p1.pid > p2.pid);
		else
			return (p1.bt > p2.bt);
	}
	else{
		return (p1.at > p2.at);
	}
}

int MIN(int a,int b){
	if(a < b)
		return a;
	return b;
}

int MAX(int a,int b){
	if(a < b)
		return b;
	return a;
}

// driver code
int main(int argc, char const *argv[])
{
	// Input from user
	int n;
	printf("\nEnter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : \n");
	scanf("%d",&n);

	double avg_wt = 0, avg_tat = 0;

	if(n == 0){
		printf("\nAverage Waiting Time : %.2lf    Average Turnaround Time : %.2lf\n", avg_wt, avg_tat);
		printf("Completion order of Processes : \n");
		return 0;
	}

	int arrival_time[n], burst_time[n];

	for(int i=0;i<n;i++)
	{
		scanf("%d %d", &arrival_time[i], &burst_time[i]);

		if(arrival_time[i] < 0 || burst_time[i] < 0){
			printf("Usage : Input Only Non-negative Values for time\n");
			exit(1);
		}
	}

	// store process data in struct array 
	process p[n];
	for(int i=0;i<n;i++)
	{
		p[i].pid = i+1;
		p[i].at = arrival_time[i];
		p[i].bt = burst_time[i];
	}

	// sort processes according to their arrival time and burst time for SJF scheduling
	qsort(p, n, sizeof(process), compFunc);

	// declare and initializ required arrays for storing times for each process
	int waiting_time[n], turnaround_time[n], completion_time[n], completion_order[n];
	memset(waiting_time, 0, sizeof(waiting_time));
	memset(turnaround_time, 0, sizeof(turnaround_time));
	memset(completion_time, -1, sizeof(completion_time));
	memset(completion_order, 0, sizeof(completion_order));

	// calculate completion time for each process
	int prev_completion_time = 0;

	completion_time[p[0].pid-1] = p[0].at + p[0].bt;
	completion_order[0] = p[0].pid;
	prev_completion_time = completion_time[p[0].pid-1];

	int iter = n-1;
	int idx = 1;
	while(iter > 0)
	{
		// On each iteration, select available and yet to complete process with min burst time
		int curr_pid = -1, curr_min_bt = 1e9+5;
		for(int i=0;i<n;i++)
		{
			if(completion_time[i] == -1 && arrival_time[i] <= prev_completion_time && burst_time[i] < curr_min_bt)
			{
				curr_min_bt = burst_time[i];
				curr_pid = i;
			}
		}

		// if no process satisfies the conditions, keep CPU idle for that time unit
		if(curr_pid == -1)
		{
			prev_completion_time++;
			continue;
		}

		completion_time[curr_pid] = arrival_time[curr_pid] + MAX(0, prev_completion_time - arrival_time[curr_pid]) + burst_time[curr_pid]; 
		// Save order of completion for each process
		completion_order[idx] = curr_pid + 1;
		prev_completion_time = completion_time[curr_pid];
		idx++;
		iter--;
	}

	// calculate turnaround time for each process and average turnaround time
	for(int i=0;i<n;i++)
	{
		turnaround_time[i] = completion_time[i] - arrival_time[i];
		avg_tat += turnaround_time[i];
	}

	avg_tat /= (double)n;

	// calculate waiting time for each process and average waiting time
	for(int i=0;i<n;i++)
	{
		waiting_time[i] = turnaround_time[i] - burst_time[i];
		avg_wt += waiting_time[i];
	}

	avg_wt /= (double)n;

	// Output 
	printf("\nScheduing Algorithm Used : Shortest Job First (SJF) (non-preemptive) \n");
	printf("\nAverage Waiting Time : %.2lf    Average Turnaround Time : %.2lf\n", avg_wt, avg_tat);
	printf("Completion order of Processes : ");
	for(int i=0;i<n;i++)
	{
		printf("P%d ", completion_order[i]);
	}
	printf("\n\n");

	// for(int i=0;i<n;i++)
	// {
	// 	printf("completion_time[%d] = %d, ", i, completion_time[i]);
	// }
	// printf("\n\n");

	// for(int i=0;i<n;i++)
	// {
	// 	printf("turnaround_time[%d] = %d, ", i, turnaround_time[i]);
	// }
	// printf("\n\n");

	// for(int i=0;i<n;i++)
	// {
	// 	printf("waiting_time[%d] = %d, ", i, waiting_time[i]);
	// }
	// printf("\n\n");

	return 0;
}
