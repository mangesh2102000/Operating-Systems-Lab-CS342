Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
Operating Systems Lab (CS342) Assignment6
FileName : README.txt

Please make sure you are in the same folder as .c files
.c file names Q1.c, Q2.c, Q3.c, Q4.c for respective questions
In all the questions, process ID is taked as the number of line(i from 1 to n) in which data for that process is provided by user input

I have given two sample examples' output for each type of scheduling algorithm 

Important Note: Burst Time for any process should be greater than 0.

#1 Write a simple C program to calculate WT, TAT, the completion order using FCFS
-> Commands to execute Q1.c along with output

$ gcc Q1.c -o Q1

Example (a)
$ ./Q1

Enter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : 
3
0 5
1 7
3 4

Scheduing Algorithm Used : First Come First Serve (FCFS) (non-preemptive)

Average Waiting Time : 4.33    Avergae Turnaround Time : 9.67
Completion order of Processes : P1 P2 P3 

Example (b)
$ ./Q1

Enter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : 
5
2 5
0 7
4 3
2 3
1 10

Scheduing Algorithm Used : First Come First Serve (FCFS) (non-preemptive)

Average Waiting Time : 12.40    Avergae Turnaround Time : 18.00
Completion order of Processes : P2 P5 P1 P4 P3 


#2 Write a simple C program to calculate WT, TAT, the completion order using SJF
-> Commands to execute Q2.c along with output

$ gcc Q2.c -o Q2

Example (a)
$ ./Q2

Enter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : 
3
0 5
1 7
3 4

Scheduing Algorithm Used : Shortest Job First (SJF) (non-preemptive)

Average Waiting Time : 3.33    Avergae Turnaround Time : 8.67
Completion order of Processes : P1 P3 P2 

Example (b)
$ ./Q2

Enter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : 
5
2 5
0 7
4 3
2 3
1 10

Scheduing Algorithm Used : Shortest Job First (SJF) (non-preemptive)

Average Waiting Time : 7.80    Avergae Turnaround Time : 13.40
Completion order of Processes : P2 P3 P4 P1 P5 


#3 Write a simple C program to calculate WT, TAT, the completion order using SRTF
-> Commands to execute Q3.c along with output

$ gcc Q3.c -o Q3

Example (a)
$ ./Q3

Enter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : 
3
0 5
1 7
3 4

Scheduing Algorithm Used : Shortest Remaining Time First (SRTF) (preemptive) 

Average Waiting Time : 3.33    Avergae Turnaround Time : 8.67
Completion order of Processes : P1 P3 P2 

Example (b)
$ ./Q3

Enter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : 
5
2 5
0 7
4 3
2 3
1 10

Scheduing Algorithm Used : Shortest Remaining Time First (SRTF) (preemptive) 

Average Waiting Time : 7.00    Avergae Turnaround Time : 12.60
Completion order of Processes : P4 P3 P1 P2 P5 

#3 Write a simple C program to calculate WT, TAT, the completion order using HRTF
-> Commands to execute Q4.c along with output

$ gcc Q4.c -o Q4

Example (a)
$ ./Q4

Enter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : 
3
0 5
1 7
3 4

Scheduing Algorithm Used : Highest Remaining Time First (HRTF) (preemptive) 

Average Waiting Time : 8.33    Avergae Turnaround Time : 13.67
Completion order of Processes : P1 P2 P3 

Example (b)
$ ./Q4

Enter number of total processes (n) and Specify arrival_time and burst_time of n processes (ith line should contain data for ith process) : 
5
2 5
0 7
4 3
2 3
1 10

Scheduing Algorithm Used : Highest Remaining Time First (HRTF) (preemptive) 

Average Waiting Time : 18.60    Avergae Turnaround Time : 24.20
Completion order of Processes : P1 P2 P3 P4 P5 




