#!/bin/bash

#Name : Chandrawanshi Mangesh Shivaji
#Roll Number : 1801CS16
#FileName : task1.sh 

if [ $# -ne "$(($1+2))" ]
then 
	echo "Error: Inappropriate Input Data is provided as Command Line Argument, Usage : ./task1.sh N n1 n2 n3 ... nN S"
else

	declare -a ARRAY 
	ARRAY_SIZE=$1

	#Initializ array with N(ARRAY_SIZE) elements from Command Line 
	ARRAY=("${@:2:$ARRAY_SIZE}")

	#Set S to last Command line Argument (Number to be searched)
	S=${@: -1}

	idx=0

	#To check if number is found or not 
	flag=0

	echo "Output for task1.sh: "

	#Iterate over the array and print out matching indices with S
	while [ $idx -lt $ARRAY_SIZE ]
	do
		if [ ${ARRAY[idx]} -eq $S ]
		then
			flag=1
			echo "$S is located at index $idx in the array" 
		fi
		((idx++))
	done

	#If S is not found in the array 
	if [ $flag -eq 0 ]
	then
		echo "Invalid Input Argument : $S not found in the array!"
	fi

fi			
