/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 3
FileName : Ques2.c 
Problem Statement : Four times Hello should be printed by child process and one time Hello by the parent process */ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

int main(void)
{
	printf("Output:\n");

	pid_t cid;

	cid = fork();  // -> C1

	if(cid)
	{
		fork();	  // -> C2
	}
	else
	{
		cid = fork();	// -> C3
		
		if(cid == 0)
		{
			fork();		// -> C4
		}
	}

	printf("Hello ");
	return 0;
}

/* Process Tree for above code 

				   P
				/     \
			P  		      C1
		  /	  \          /  \
		P      C2      C1  	  C3
							 /	\
							C3   C4 	

*/