/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 3
FileName : Ques3.c 
Problem Statement : Write a C program which creates one parent process and one child process. The child
process will execute the task1.sh and parent process will execute the task2.sh */ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

int main(int argc, char *argv[])
{
	pid_t pid = fork();

	// Check if valid child is created or not 
	if(pid < 0)
	{
		printf("Can't Fork!\n");
		exit(1);
	}

	if(pid == 0)
	{
		char* arguments1[105] = {"bash","task1.sh"};
		
		// Write Input for task1.sh from CLA to arguments1
		int idx=2;
		while(idx != argc)
		{
			arguments1[idx] = argv[idx-1];
			idx++;
		}
		arguments1[idx] = NULL;

		// Execute task1.sh 
		execv("/bin/bash", arguments1);
		
		printf("Return not expected. Must be an execv error\n");
	}
	else
	{		
		// Write Input for task2.sh from CLA to arguments2
		char* arguments2[105] = {"bash","task2.sh",argv[argc-1],NULL};

		// Execute task2.sh
		execv("/bin/bash", arguments2);

		printf("Return not expected. Must be an execv error\n");
	}

	return 0;
}


