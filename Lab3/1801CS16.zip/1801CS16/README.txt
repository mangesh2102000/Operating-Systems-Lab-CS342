Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
Operating Systems Lab (CS342) Assignment3
FileName : README.txt

Please make sure you are in the same folder as .C and .sh files while execution

.C file names Ques1.c, Ques2.c and Ques3.c for respective questions 
.sh file names are task1.sh and task2.sh (for Ques3)

#1 Create 2 child process using fork() system call, Child 1 for adding two integers and Child 2 for multiplying
two integers. The parent process should divide the results of Child 2 by the result of Child 1. All the results
must be printed along with the respective process ids. The input integers should be given as command line arguments.

-> Commands to execute Ques1.c along with output for few test examples

$ gcc -o Ques1 Ques1.c 

// Usage : ./Ques1 num1 num2

$ ./Ques1 2 2
Sum by Child 14863 : 4
Multiplication by Child 14864 : 4
Division by Parent 14862 : 1.00

$ ./Ques1 3 56
Sum by Child 14869 : 59
Multiplication by Child 14870 : 168
Division by Parent 14868 : 2.85

$ ./Ques1 -2 34
Sum by Child 14872 : 32
Multiplication by Child 14873 : -68
Division by Parent 14871 : -2.12

Note :  Division Result is a float rounded off to 2 decimals



#2 Modify the box given below using fork() system calls over a parent process to create 4 child processes and 
print the following output. Here, four times Hello should be printed by child process and one time Hello by the
parent process.

-> Commands to execute Ques2.c along with output for few test examples 

$$ gcc -o Ques2 Ques2.c 

// Usage : ./Ques2

$ ./Ques2
Output:
Hello Hello Hello Hello Hello 

Note : /* Process Tree is in commented below code which explains creation of 4 child processes */



#3 Write two shell scripts named task1.sh and task2.sh for the following tasks respectively:
•
	A shell program that will create an array of size N having values n1 , n2 ,n3....... nN.Print a message “Search
	found along with its index of searched item S”. All the values(N, ni , S) should be taken from the Command Line
	Argument(CLA). Note: If the searched item does not contain in the array then output an error message.
• 
	A recursive shell program that should output the product of factorial of a number with the sum of all the prime
	no. less than equal to that number. Take N from CLA. E.g : N = n , Output = fact(n) * PrimeNoLessThan(n) = n * 
	fact(n-1) * (if(n⋿ Prime number) + PrimeNoLessThan(n-1) )

Now, write a C program which creates one parent process and one child process. The child process will execute the 
task1.sh and parent process will execute the task2.sh.

-> Commands to execute Ques3.c along with output for few test examples 

$$ gcc -o Ques3 Ques3.c

// Usage : ./Ques3 N n1 n2 n3 .. nN S N
// So the last CLA will be the number used for task2.sh and prior to that will be the used input for task1.sh
// All input argument variables have similar meaning as in question 

$ ./Ques3 5 1 2 3 4 3 3 5
Output for task1.sh: 
3 is located at index 2 in the array
3 is located at index 4 in the array
Output for task2.sh: 
Factorial of 5 is 120  and  Sum of all the prime no. less than equal to 5 is 10
1200


$ ./Ques3 10 1 22 3 1 25 31 2 1 32 5 1 10
Output for task1.sh: 
1 is located at index 0 in the array
1 is located at index 3 in the array
1 is located at index 7 in the array
Output for task2.sh: 
Factorial of 10 is 3628800  and  Sum of all the prime no. less than equal to 10 is 17
61689600

Note : For task2.sh result may overflow for larger values (out of limit)