#!/bin/bash

#Name : Chandrawanshi Mangesh Shivaji
#Roll Number : 1801CS16
#FileName : task2.sh 

#Function to Check if Number is prime or not
is_prime()
{
	if [ $1 -lt 2 ]
	then
		echo 0
	else

		n=$1
		i=2
		flag=1

		while [ $i -lt $n ]
		do
			if [ $(($n%$i)) -eq 0 ]
			then
				flag=0
				break
			fi
			((i++))
		done

		echo "$flag" 
	fi	
}

#Recursive Function to Calculate factorial
fact()
{
    if [ $1 -le 1 ]
    then
        echo 1
    else
        fact_last=$(fact $(($1-1)))
        echo $(($1*fact_last))
    fi
}

#Recursive Function to Calculate Sum of Prime Numbers less than a Number
PrimeNoLessThan()
{
	if [ $1 -le 1 ]
    then
        echo 0
    else 
    	PrimeNoLessThan_last=$(PrimeNoLessThan $(($1-1)))
		if [ $(is_prime $1) -eq 1 ]
		then 
			echo $(($1 + PrimeNoLessThan_last))
		else
			echo $PrimeNoLessThan_last
		fi
	fi
}

#Main Code
if [ $# -ne 1 ]
then 
	echo "Error: Inappropriate Input Data is provided as Command Line Argument, Usage : ./task2.sh NUMBER"
else
	NUMBER=$1

	Output=$(($(fact $NUMBER)*$(PrimeNoLessThan $NUMBER)))

	echo "Output for task2.sh: "

	echo "Factorial of $NUMBER is $(fact $NUMBER)  and  Sum of all the prime no. less than equal to $NUMBER is $(PrimeNoLessThan $NUMBER)"

	echo "$Output"
fi			
