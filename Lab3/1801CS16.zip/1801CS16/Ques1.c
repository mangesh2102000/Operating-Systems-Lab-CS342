/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 3
FileName : Ques1.c 
Problem Statement : Create 2 child process using fork() system call, Child 1 for adding two integers and Child 2 for
multiplying two integers. The parent process should divide the results of Child 2 by the result of Child 1*/ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h> 

int main(int argc, char *argv[])
{
	if(argc != 3)
	{
		printf("Invalid arguments, Usage : ./Ques1 num1 num2\n");
		return 0;
	}	

	int num1=atoi(argv[1]), num2=atoi(argv[2]);

	/* Create Pipeline to transfer/recieve value between processes */
	int fd[2]; /* fd[0] - read and fd[1] - write */
	pipe(fd);

	pid_t pid = fork();

	// Check if valid child is created or not 
	if(pid < 0)
	{
		printf("Can't fork!\n");
		exit(1);
	}

	if(pid == 0)
	{
		// Addition by Process Child1
		int sum_by_child1 = num1 + num2;

		write(fd[1],&sum_by_child1,sizeof(int));
		
		printf("Sum by Child %d : %d\n", getpid(), sum_by_child1);
	}
	else
	{
		pid = fork();

		if(pid < 0)
		{
			printf("Can't fork!\n");
			exit(1);
		}

		if( pid == 0 )
		{
			// Multiplication by Process Child2
			int mult_by_child2 = num1*num2;
			
			write(fd[1],&mult_by_child2,sizeof(int));
			
			printf("Multiplication by Child %d : %d\n", getpid(), mult_by_child2);
		}
		else
		{
			wait(NULL);

			// Division by Parent 
			int sum_by_child1,mult_by_child2;
			
			read(fd[0],&sum_by_child1,sizeof(int));
			read(fd[0],&mult_by_child2,sizeof(int));
			
			float div_by_parent = (float)(mult_by_child2) / (sum_by_child1);
			
			printf("Division by Parent %d : %.2f\n", getpid(), div_by_parent);
		}
	}

	return 0;
}



