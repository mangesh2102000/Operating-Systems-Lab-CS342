/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 4
FileName : Q4.c 
Problem Statement : 
- First child will copy the content of file1 to file2.
- Second child will display the content of file2.
- Third child will display the sorted content of file2 in reverse order.
- Each child process being created will display its id and its parent process id with
appropriate message.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h> 

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

int main(int argc, char *argv[])
{
	if(argc != 4)
	{
		printf("Invalid arguments, Usage : ./a.out fileName1 fileName2 option\noption = 1; if data is only numbers\noption = 2; if data is strings\n");
		return 0;
	}

   	int options = atoi(argv[3]);

   	if(options != 1 && options != 2)
   	{		
   		printf("Invalid arguments, Usage : ./a.out fileName1 fileName2 option\noption = 1; if data is only numbers\noption = 2; if data is strings\n");
		return 0;
   	}

	pid_t pid = fork();

	// Check if valid child is created or not 
	if(pid < 0)
	{
		printf("Can't fork!\n");
		exit(1);
	}

	FILE *fp1 = fopen(argv[1], "r"); 
   	FILE *fp2 = fopen(argv[2], "w+"); 

   	if( fp1 == NULL || fp2 == NULL )
   	{
   		printf("Could not open both files!\n");
   		exit(0);
   	}

   
	// Child1
	if(pid == 0)
	{
		printf("\nChild 1 Process ID : %d, Parent Process ID : %d \n\n",getpid(),getppid());

		printf("Copying Content from %s to %s ... ",argv[1],argv[2]);
		char c;
		while( (c=fgetc(fp1)) != EOF )
		{
			fputc(c, fp2);
		}
		printf("Successfully Copied\n");

	}
	else
	{
		wait(NULL);

		pid = fork();

		// Child2
		if(pid == 0)
		{
			printf("\nChild 2 Process ID : %d, Parent Process ID : %d \n\n",getpid(),getppid());

			printf("Display Content of %s : \n",argv[2]);

			fseek(fp2,0,SEEK_SET);
			char c;
			while( (c=fgetc(fp2)) != EOF )
			{
				printf("%c",c);
			}

			printf("\n(not part of the file) Successfully Displayed\n");
		}
		else
		{
			wait(NULL);

			pid = fork();

			// Child3
			if(pid == 0)
			{
				printf("\nChild 3 Process ID : %d, Parent Process ID : %d \n\n",getpid(),getppid());

				printf("Display the sorted content of %s in reverse order : \n",argv[2]);

				fseek(fp2,0,SEEK_SET);

                char data[505][505];
                int val[505];
                memset(data,'\0',sizeof(data));

                int idx = 0;
                while(fscanf(fp2,"%s",data[idx]) == 1)
                {
                	val[idx] = atoi(data[idx]);
                	idx++;
                }

                if(options == 1)
                {
                	qsort(val, idx, sizeof(int), cmpfunc);

					for(int i=idx-1;i>=0;i--)
					{
						printf("%d\n",val[i]);
					}
             	}
             	else if(options == 2)
                {	
	                for(int i=0;i<idx;i++)
	                {
	                	for(int j=i+1;j<idx;j++)
	                	{
	                		if(strcmp(data[i],data[j]) > 0)
	                		{
	                			char tmp[505];
	                			strcpy(tmp,data[i]);
	                			strcpy(data[i],data[j]);
	                			strcpy(data[j],tmp);
	                		}
	                	}
	                }

                	for(int i=idx-1;i>=0;i--)
					{
						printf("%s\n",data[i]);
					}
                }
    			
				printf("(not part of the file) Successfully Displayed\n");
				
			}
			else
			{
				wait(NULL);
			}

		}
	}

	fclose(fp1);
	fclose(fp2);

	return 0;
}




                