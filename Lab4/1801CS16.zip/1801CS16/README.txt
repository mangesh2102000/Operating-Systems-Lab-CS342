Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
Operating Systems Lab (CS342) Assignment4
FileName : README.txt

Please make sure you are in the same folder as .c 

.c file names Q1.c, Q2.c, Q3.c and Q4.c for respective questions 
numbers1.txt and strings1.txt are sample example files for question 4

#1 Write a program in C to create a child process using a "fork" system call and convert it to
a zombie process. Show that the child process becomes a zombie process.

-> Commands to execute Ques1.c along with output explanation

In Terminal 1 :

$ gcc Q1.c 

$ ./a.out
Child Process ID : 14552, Parent Process ID : 14551

In other Terminal 2 : 

When the program is still running, 

$ ps -ef | grep a.out
mangesh+   14551   13960  0 17:19 pts/0    00:00:00 ./a.out
mangesh+   14552   14551  0 17:19 pts/0    00:00:00 [a.out] <defunct>		// Zombie Process
mangesh+   14556   14038  0 17:19 pts/1    00:00:00 grep --color=auto a.out

Here, we can clearly see the child process (14552) is defunct i.e. a zombie process

Generally, the child process is monitored by wait(), but here parent executes sleep() and the correspondence 
between parent and child process is absent which leads to child process becoming a zombie process.

After program has completed its execution,

$ ps -ef | grep a.out
mangesh+   14564   14038  0 17:21 pts/1    00:00:00 grep --color=auto a.out

defunct (Zombie) Process also exits




#2 Create a child process and make it an orphan process. What is the significance of the
orphan process?

-> Commands to execute Q2.c along with output explanation 

$ gcc Q2.c

$ ./a.out
Parent Process ID : 16054

Child Process ID : 16055, Parent Process ID : 16054

//
After this Parent Process (16054) exits making the child process (16055) orphan ,after that it is
adopted by another process (init process generally)

$ Child Process ID : 16055, Parent Process ID : 2060

//
This is the statement printed before termnation of child process (i.e. 20 seconds after parent process in this program ).
Changed Parent Process ID (2060) from (16054) should be noticed.

# Significance of Orphan Pocess : 

A process can be orphaned either intentionally or unintentionally.

Sometime a parent process exits/terminates or crashes leaving the child process still running, and then they become orphans.

Also, a process can be intentionally orphaned just to keep it running. For example when you need to run a job in the background
which don’t need any manual intervention and going to take long time, then you detach it from user session and leave it there. Same
way, when you need to run a process in the background for infinite time, you need to do the same thing. Processes running in the
background like this are known as daemon process.

At the same time, when a client connects to a remote server and initiated a process, and due to some reason the client crashes
unexpectedly, the process on the server becomes Orphan.




#3 Write a C program that will create a child process to generate a Fibonacci series of specified length 
and store it in an array. The parent process will wait for the child to complete its task and then display
the Fibonacci series and then display the prime Fibonacci number in the series along with its position

-> Commands to execute Q3.c along with output

$ gcc Q3.c 

Usage : ./a.out N 

where, N is number of fibonacci numbers required 

(Example 1)

$ ./a.out 15
Child Process ID : 19156, Parent Process ID : 19155 

Current Process ID : 19156 -> 

Current Process ID : 19155 -> 

Fibonacci Series : 1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 

Prime Fibonacci Numbers along with their positions (1 index based) : 

Number : 2, Position : 3
Number : 3, Position : 4
Number : 5, Position : 5
Number : 13, Position : 7
Number : 89, Position : 11
Number : 233, Position : 13

(Example 2)

$ ./a.out 20
Child Process ID : 19158, Parent Process ID : 19157 

Current Process ID : 19158 -> 

Current Process ID : 19157 -> 

Fibonacci Series : 1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 1597 2584 4181 6765 

Prime Fibonacci Numbers along with their positions (1 index based) : 

Number : 2, Position : 3
Number : 3, Position : 4
Number : 5, Position : 5
Number : 13, Position : 7
Number : 89, Position : 11
Number : 233, Position : 13
Number : 1597, Position : 17




#4. Write a C program that will create three child process to perform the following operations respectively:
- First child will copy the content of file1 to file2.
- Second child will display the content of file2.
- Third child will display the sorted content of file2 in reverse order. 
(Note : Here, the content of file2 remains same,  just the reverse sorted order is displayed)
- Each child process being created will display its id and its parent process id with appropriate message.

-> Commands to execute Q4.c along with output

$ gcc Q4.c 

Usage : ./a.out fileName1 fileName2 option

where, option = 1; if data is only numbers
	   option = 2; if data is strings

(Example 1) : file1 with only numbers (option = 1; will be used)

$ ./a.out numbers1.txt numbers2.txt 1

Child 1 Process ID : 23272, Parent Process ID : 23271 

Copying Content from numbers1.txt to numbers2.txt ... Successfully Copied

Child 2 Process ID : 23274, Parent Process ID : 23271 

Display Content of numbers2.txt : 
234
31
322
332
2858
8242
(not part of the file) Successfully Displayed

Child 3 Process ID : 23275, Parent Process ID : 23271 

Display the sorted content of numbers2.txt in reverse order : 
8242
2858
332
322
234
31
(not part of the file) Successfully Displayed


(Example 2) : file1 with strings (option = 2, will be used)

$ ./a.out strings1.txt strings2.txt 2

Child 1 Process ID : 23414, Parent Process ID : 23413 

Copying Content from strings1.txt to strings2.txt ... Successfully Copied

Child 2 Process ID : 23416, Parent Process ID : 23413 

Display Content of strings2.txt : 
aaabc
uuuchc
cmslcns
csnicns
caaa
xaaaa
ccihac
bcbca
canoqnfc
csocna
ouuqbc
bcdv
(not part of the file) Successfully Displayed

Child 3 Process ID : 23417, Parent Process ID : 23413 

Display the sorted content of strings2.txt in reverse order : 
xaaaa
uuuchc
ouuqbc
csocna
csnicns
cmslcns
ccihac
canoqnfc
caaa
bcdv
bcbca
aaabc
(not part of the file) Successfully Displayed
