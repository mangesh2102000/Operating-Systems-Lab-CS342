/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 4
FileName : Q3.c 
Problem Statement : create a child process to generate a Fibonacci series of specified length 
and store it in an array. The parent process will wait for the child to complete its task and
then display the Fibonacci series and then display the prime Fibonacci number in the series 
along with its position.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h> 

// function to check prime numbers 
int is_prime(int x)
{
	if(x <= 1)
		return 0;

	for(int i=2;i*i<=x;i++)
	{
		if(x%i == 0)
			return 0;
	}

	return 1;
}

int main(int argc, char *argv[])
{
	if(argc != 2)
	{
		printf("Invalid arguments, Usage : ./a.out N\n");
		return 0;
	}	

	int N=atoi(argv[1]);

	/* Create Pipeline to transfer/recieve value between processes */
	int fd[2]; /* fd[0] - read and fd[1] - write */
	pipe(fd);

	pid_t pid = fork();

	// Check if valid child is created or not 
	if(pid < 0)
	{
		printf("Can't fork!\n");
		exit(1);
	}

	if(pid == 0)
	{
		printf("Child Process ID : %d, Parent Process ID : %d \n\n",getpid(),getppid());

		printf("Current Process ID : %d -> \n\n", getpid());

		// Calculate N fibonacci numbers and store them in an array
		int f0=0,f1=1,f2;
		int fib[N];

		if(N == 0)
			exit(0);

		fib[0]=1;

		for(int i=1;i<N;i++)
		{
			f2 = f0 + f1;
			f0 = f1;
			f1 = f2;
			fib[i] = f2;
		}

		write(fd[1],fib,sizeof(int)*N);

	}
	else
	{
		wait(NULL);

		int fib_parent[N];

		// Store N fibonacci numbers into an array, read from pipe between child and parent
		read(fd[0],fib_parent,sizeof(int)*N);

		printf("Current Process ID : %d -> \n\n", getpid());

		printf("Fibonacci Series : ");
	
		for(int i=0;i<N;i++)
		{
			printf("%d ",fib_parent[i]);
		}
		printf("\n\n");

		printf("Prime Fibonacci Numbers along with their positions (1 index based) : \n\n");

		for(int i=0;i<N;i++)
		{
			if(is_prime(fib_parent[i]))
			{
				printf("Number : %d, Position : %d\n",fib_parent[i],i+1);
			}
		}

		printf("\n");	
	}

	return 0;
}



