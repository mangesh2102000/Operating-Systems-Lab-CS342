/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 4
FileName : Q1.c 
Problem Statement : Create a child process using a "fork" system call and convert it to a zombie process */

/* Explanation in README */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h> 


int main(int argc, char *argv[])
{
	pid_t pid = fork();

	if( pid < 0 )
	{
		printf("Process Creation Failed!\n");
		exit(1);
	}

	if( pid > 0 )
	{
		// parent process
		sleep(30);				// Due to this, child process becomes a Zombie Process for about 30 seconds
	}
	else if( pid == 0 )
	{
		// child process
		printf("Child Process ID : %d, Parent Process ID : %d\n",getpid(),getppid());
		exit(0);
	}

	return 0;
}



