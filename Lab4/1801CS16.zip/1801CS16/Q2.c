/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 4
FileName : Q2.c 
Problem Statement : Create a child process and make it an orphan process. Significance of orphan Process*/

/* Explanation and Significance of Orphan Process in README */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h> 


int main(int argc, char *argv[])
{
	pid_t pid = fork();

	if( pid < 0 )
	{
		printf("Process Creation Failed!\n");
		exit(1);
	}

	if( pid > 0 )
	{
		// parent process
		printf("Parent Process ID : %d\n\n",getpid());
	}
	else if( pid == 0 )
	{
		// child process
		printf("Child Process ID : %d, Parent Process ID : %d\n\n",getpid(),getppid());

		sleep(20);				// Due to this, child process becomes a Orphan Process for some time before it is adopted by init process

		printf("Child Process ID : %d, Parent Process ID : %d\n\n",getpid(),getppid());
	}

	return 0;
}



