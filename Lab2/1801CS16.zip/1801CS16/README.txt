Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
Operating Systems Lab (CS342) Assignment2
FileName : README.txt

Please make sure you are in the same folder as script file while execution

script file names script1.sh, script2.sh, script3.sh, script4.sh for respective questions 

Q3.c is the C program file for Question 3

#1 Write a shell program that will create an array of size N having values n 1 , n 2 ,n 3 .......
n N .Print a message “Search found along with its index of searched item S”. All the values(N, n i , S) 
should be taken from the Command Line Argument(CLA). Note: If the searched item does not contain in the 
array then output an error message. 

-> Commands to execute script1.sh along with output for few test examples (after making the script executable)

$ chmod u+x script1.sh 

$ ./script1.sh 5 1 2 2 3 2 2
2 is located at index 1 in the array
2 is located at index 2 in the array
2 is located at index 4 in the array

$ ./script1.sh 10 1 2 3 4 5 1 3 5 2 4 6
Invalid Input Argument : 6 not found in the array!

$ ./script1.sh 2 3 3 3 3
Error: Inappropriate Input Data is provided as Command Line Argument, Usage : ./script1.sh N n1 n2 n3 ... nN S


#2 Write a recursive shell program that should output the product of factorial of a number with the sum of all 
the prime no. less than equal to that number. Take N from CLA.
E.g : N = n , Output = fact(n) * PrimeNoLessThan(n) = n * fact(n-1) * (if(n⋿ Prime number) + PrimeNoLessThan(n-1) )

-> Commands to execute script2.sh along with output for few test examples (after making the script executable)

$ chmod u+x script2.sh 

$ ./script2.sh 5
Factorial of 5 is 120  and  Sum of all the prime no. less than equal to 5 is 10
1200

$ ./script2.sh 18
Factorial of 18 is 6402373705728000  and  Sum of all the prime no. less than equal to 18 is 58
371337674932224000

$ ./script2.sh 20 15
Error: Inappropriate Input Data is provided as Command Line Argument, Usage : ./script2.sh NUMBER

Note : Input Number shoud be less than or equal to 18 (Otherwise the answer maybe be wrong due to overflow)


#3 Implement an XOR function using a shell script that will take two numbers as CLA and output its XOR. 
Note: You need to convert the inputs in binary form. Also, implement the same using python/C and observe
time taken by both the programs for the same input(>100).

-> Commands to execute script3.sh and Q3.c along with output for few test examples and execution time analysis
for both C and sh programs (after making the script executable)

#Input1 num1 = 125 and num2 = 365  

$ chmod u+x script3.sh 
$ time ./script3.sh 125 365
Output : 
Binary Conversion : 
125 => 0000000000000000000000000000000000000000000000000000000001111101
365 => 0000000000000000000000000000000000000000000000000000000101101101
XOR of 125 and 365 in binary is 0000000000000000000000000000000000000000000000000000000100010000
XOR of 125 and 365 in decimal is 272

real	0m0.022s
user	0m0.015s
sys	0m0.008s

$ gcc Q3.c 						// Compile C Program, generates execuatble file a.out 
$ time ./a.out 125 365			
Binary of first number : 0000000000000000000000000000000000000000000000000000000101111100
Binary of second number : 0000000000000000000000000000000000000000000000000000000101101101
Xor of given two numbers : 0000000000000000000000000000000000000000000000000000000000010001

real	0m0.002s
user	0m0.002s
sys	0m0.000s

So we can observe from this input that C programs executable file runs about 10X times faster than the bash shell script file.

#Input2 num1 = 1000000 num2 = 225533

$ time ./script3.sh 1000000 225533
Output : 
Binary Conversion : 
1000000 => 0000000000000000000000000000000000000000000011110100001001000000
225533 => 0000000000000000000000000000000000000000000000110111000011111101
XOR of 1000000 and 225533 in binary is 0000000000000000000000000000000000000000000011000011001010111101
XOR of 1000000 and 225533 in decimal is 799421

real	0m0.021s
user	0m0.015s
sys	0m0.007s

$ time ./a.out 1000000 225533
Binary of first number : 0000000000000000000000000000000000000000000000000010010000101111
Binary of second number : 0000000000000000000000000000000000000000000010111111000011101100
Xor of given two numbers : 0000000000000000000000000000000000000000000010111101010011000011

real	0m0.002s
user	0m0.002s
sys	0m0.000s

Again we observe similar kind of time results in both the cases 

Note :  All binary numbers listed are in 64 bits 

#4 Write a shell script to validate password strength. Here are a few assumptions for the password string.
Length – a minimum of 7 characters.
Contain both alphabet and number.
Contain one special char ( /, (, ),<, >, ? )
If the password doesn’t comply with any of the above conditions, then the programshould report it as a <Invalid Password>.

-> 
Commands to execute script4.sh along with output for few test examples (after making the script executable)

$ chmod u+x script4.sh 

$ ./script4.sh abcABC
<Invalid Password>

$ ./script4.sh abcABC123
<Invalid Password>

$ ./script4.sh abcABC1?23
Password is Valid!

$ ./script4.sh abcA///C
<Invalid Password>

$ ./script4.sh a1?
<Invalid Password>

$ ./script4.sh a1?aaaaaaa
Password is Valid!
