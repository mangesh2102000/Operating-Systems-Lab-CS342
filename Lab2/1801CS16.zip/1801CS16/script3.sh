#!/bin/bash

#Name : Chandrawanshi Mangesh Shivaji
#Roll Number : 1801CS16
#FileName : script3.sh 

decimal_to_binary()
{
	num=$1
	result=""
	for ((i = 0; i < 64; ++i))
	do
		result=$((num%2))$result
		num=$((num/2))
	done
	echo "$result"
}

binary_to_decimal() 
{
	result=0
	num=$1
	for ((i = 0; i < 64; ++i))
	do
		curr_bit=${num:i:1}
		result=$((result*2+curr_bit))
	done
	echo "$result"
}

#Function to calculate XOR of two given numbers  
XOR()
{
	NUMBER1=$1
	NUMBER2=$2

	BIN1=$(decimal_to_binary $NUMBER1)
	BIN2=$(decimal_to_binary $NUMBER2)

	i=0
	RESULT=""
	curr_bit1=""
	curr_bit2=""

	LEN=${#BIN1}

	#Iterate bit by bit and calculate XOR
	while [ $i -lt $LEN ]
	do 
		curr_bit1=${BIN1:i:1}
		curr_bit2=${BIN2:i:1}
		if [ $curr_bit1 -eq $curr_bit2 ]
		then 
			RESULT+="0"
		else
			RESULT+="1"
		fi
		((i++))
	done

	echo "$RESULT"
}

if [ $# -ne 2 ]
then 
	echo "Error: Inappropriate Input Data is provided as Command Line Argument, Usage : ./script3.sh NUMBER1 NUMBER2"
else

	NUMBER1=$1
	NUMBER2=$2

	echo "Output : "

	echo "Binary Conversion : "
	echo "$NUMBER1 => $(decimal_to_binary $NUMBER1)"
	echo "$NUMBER2 => $(decimal_to_binary $NUMBER2)"

	XOR_result=$(XOR $NUMBER1 $NUMBER2)

	echo "XOR of $NUMBER1 and $NUMBER2 in binary is $XOR_result"

	echo "XOR of $NUMBER1 and $NUMBER2 in decimal is $(binary_to_decimal $XOR_result)"

fi			
