#!/bin/bash

#Name : Chandrawanshi Mangesh Shivaji
#Roll Number : 1801CS16
#FileName : script4.sh 

if [ $# -ne 1 ]
then 
	echo "Error: Inappropriate Input Data is provided as Command Line Argument, Usage : ./script1.sh Password"
else

	Password=$1
	len=${#Password}
	
	#Check for Length Validity
	if [ $len -lt 7 ]
	then 
		echo "<Invalid Password>"
		exit
	fi

	alphabets="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	digits="0123456789"
	specials="/()<>?"

	len1=${#alphabets}
	len2=${#digits}
	len3=${#specials}

	alpha=0
	number=0
	special=0

	for ((i=0; i<$len; i++))
	do
		curr_char=${Password:i:1}

		#Check for Alphabet
		for ((j=0; j<$len1; j++))
		do 
			match_char=${alphabets:j:1}
			if [ $curr_char = $match_char ]
			then
				alpha=1
				break
			fi
		done

		#Check for number
		for ((j=0; j<$len2; j++))
		do 
			match_char=${digits:j:1}
			if [ $curr_char = $match_char ]
			then
				number=1
				break
			fi
		done

		#Check for special characters
		for ((j=0; j<$len3; j++))
		do 
			match_char=${specials:j:1}
			if [ $curr_char = $match_char ]
			then
				special=1
				break
			fi
		done

	done

	#IF all are present valid password
	if [ $alpha = 1 ] && [ $number = 1 ] && [ $special = 1 ]
	then
		echo "Password is Valid!"
		exit
	fi 

	#ELSE invalid 
	echo "<Invalid Password>"
fi			
