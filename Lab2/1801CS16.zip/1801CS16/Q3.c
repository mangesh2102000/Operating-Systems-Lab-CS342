//Name : Chandrawanshi Mangesh Shivaji
//Roll Number : 1801CS16
//FileName : Q3.c 

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char *argv[])
{
	int num1=atoi(argv[1]),num2=atoi(argv[2]);
	int bin1[105]={0},bin2[105]={0},xor[105]={0};

	int idx1=0,idx2=0;
	while(num1)
	{
		bin1[idx1++]=(num1%2);
		num1/=2;
	}

	while(num2)
	{
		bin2[idx2++]=(num2%2);
		num2/=2;
	}

	int max_len = (idx1>idx2)?idx1:idx2;

	int l=0,r=max_len-1;
	while(l<r)
	{
		int tmp = bin1[l];
		bin1[l] = bin1[r];
		bin1[r] = tmp;
		l++;
		r--;
	}

	l=0,r=max_len-1;
	while(l<r)
	{
		int tmp = bin2[l];
		bin2[l] = bin2[r];
		bin2[r] = tmp;
		l++;
		r--;
	}

	for(int i=0;i<64;i++)
	{
		xor[i] = (bin1[i]+bin2[i])%2;
	}

	printf("Binary of first number : ");
	for(int i=63;i>=0;i--)
	{
		printf("%d",bin1[i]);
	}
	printf("\n");

	printf("Binary of second number : ");
	for(int i=63;i>=0;i--)
	{
		printf("%d",bin2[i]);
	}
	printf("\n");

	printf("Xor of given two numbers : ");
	for(int i=63;i>=0;i--)
	{
		printf("%d",xor[i]);
	}
	printf("\n");

    return 0;
}
