/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - MID SEM EXAM 2021
FileName : README.txt*/

Please make sure you are in the same folder as .c files
.c file names Q1.c, Q2a.c, Q2b.c, Q3.c, Q4.c for respective questions

Q1) =>

/* Result : 

Compilation : $ gcc Q1.c -o Q1

Usage with example : 

mangesh2102000@Linux-Ubuntu:~/Documents$ ./Q1
Parent Process ID : 7173
mangesh2102000@Linux-Ubuntu:~/Documents$ 
Orphan Process : 
Child Process ID : 7174, Parent Process ID : 2266
Note the change in Parent Process ID of Child Process 7174

Zombie Process : 
Child Process ID : 7175, Parent Process ID : 7174
ps aux | grep 7175		// This command is manually used to check process details 
mangesh+    7175  0.0  0.0      0     0 pts/0    Z    16:05   0:00 [Q1] <defunct>
mangesh+    7177  0.0  0.0   8884   880 pts/0    S+   16:05   0:00 grep --color=auto 7175
mangesh2102000@Linux-Ubuntu:~/Documents$ 

*/

Q2a) =>

/* Result : 

Compilation : $ gcc Q2a.c -o Q2a

Usage wiht examples :

mangesh2102000@Linux-Ubuntu:~/Documents$ ./Q2a 10

Child 3 Process ID : 10985, Computed sum of positive non-prime nubers in the series : 1.111111
Child 2 Process ID : 10984, Computed sum of positive prime nubers in the series : 0.676190
Child 1 Process ID : 10983, Computed sum of negative numbers in the series : -1.141667
Parent Process ID : 10982, Final Result of the series i.e. sum of all numbers : 0.645635

$ ./Q2a 1000000

Child 3 Process ID : 11061, Computed sum of positive non-prime nubers in the series : 5.155609
Child 2 Process ID : 11060, Computed sum of positive prime nubers in the series : 2.387328
Child 1 Process ID : 11059, Computed sum of negative numbers in the series : -6.849790
Parent Process ID : 11058, Final Result of the series i.e. sum of all numbers : 0.693147

We can observe than sum of series is tending to ln(2) for large numbers.

*/



Q2b) =>

Note : In output of this question the order may not be adequate/proper due to concurrenct execution of threads;
following result is taken from example where output was in order.

All threads will execute before exit of main program

/* Result : 

Compilation : $ gcc Q2b.c -o Q2b -lm -pthread

Usage with examples : 

mangesh2102000@Linux-Ubuntu:~/Documents$ ./Q2b

Enter dimension for Matrix A (Format: num_rows num_cols) : 3 3
Enter elements for Matrix A (Format:
[ A(0,0) A(0,1) .. A(0,num_cols-1)
  A(1,0) A(1,1) .. A(1,num_cols-1)
  ....
  A(num_rows-1,0) A(num_rows-1,1) .. A(num_rows-1,num_cols-1) ] )
1 2 3
1 5 9
9 7 5

Enter dimension for Matrix B (Format: num_rows num_cols) : 3 3
Enter elements for Matrix B (Format:
[ B(0,0) B(0,1) .. B(0,num_cols-1)
  B(1,0) B(1,1) .. B(1,num_cols-1)
  ....
  B(num_rows-1,0) B(num_rows-1,1) .. B(num_rows-1,num_cols-1) ] )
-2 3 1
2 5 7
1 5 3

Enter dimension for Matrix C (Format: num_rows num_cols) : 3 3
Enter elements for Matrix C (Format:
[ C(0,0) C(0,1) .. C(0,num_cols-1)
  C(1,0) C(1,1) .. C(1,num_cols-1)
  ....
  C(num_rows-1,0) C(num_rows-1,1) .. C(num_rows-1,num_cols-1) ] )
2 5 8
9 4 6
7 8 3

Output from Thread 1 (Thread ID : 0x7fd1cba63640) 
Matrix A + B : 
-1 5 4 
3 10 16 
10 12 8 

Matrix B + A : 
-1 5 4 
3 10 16 
10 12 8 


As A and B are matrices of same order 3 x 3 => A + B = B + A i.e. Commutaive

Output from Thread 2 (Thread ID : 0x7fd1cba63640) 
Matrix A + B : 
-1 5 4 
3 10 16 
10 12 8 

Matrix (A + B) + C: 
1 10 12 
12 14 22 
17 20 11 

Matrix B + C : 
0 8 9 
11 9 13 
8 13 6 

Matrix A + (B + C): 
1 10 12 
12 14 22 
17 20 11 


As A, B, C are matrices of same order 3 x 3 => (A + B) + C = A + (B + C) i.e. Associative

Output from Thread 3 (Thread ID : 0x7fd1cba63640) 

Additive Identity for Matrix A : 
0 0 0 
0 0 0 
0 0 0 


Verification A + O = O + A = A : 
1 2 3 
1 5 9 
9 7 5 


Output from Thread 4 (Thread ID : 0x7fd1cba63640) 

Additive Inverse for Matrix A : 
-1 -2 -3 
-1 -5 -9 
-9 -7 -5 


Verification A + (-A) = O : 
0 0 0 
0 0 0 
0 0 0 

*/



Q3) =>

/* Result : 

Compilation : $ gcc Q3.c -o Q3

Usage with examples : 

mangesh2102000@Linux-Ubuntu:~/Documents$ ./Q3

Enter number of total processes (n) and Specify arrival_time, Priority and burst_time of n processes (ith line should contain data for ith process) : 
7
0 2 1
1 6 7
2 3 3
3 5 6
4 4 5
5 10 15
15 9 8

Scheduing Algorithm Used : Priority (preemptive​) scheduling algorithm 

Average Waiting Time : 18.43    Average Turnaround Time : 24.86
Completion order of Processes : P1 P6 P7 P2 P4 P5 P3 

mangesh2102000@Linux-Ubuntu:~/Documents$ ./Q3

Enter number of total processes (n) and Specify arrival_time, Priority and burst_time of n processes (ith line should contain data for ith process) : 
4
0 1 9
1 3 4
1 2 3
0 2 4

Scheduing Algorithm Used : Priority (preemptive​) scheduling algorithm 

Average Waiting Time : 5.50    Average Turnaround Time : 10.50
Completion order of Processes : P2 P4 P3 P1 


Note : Average Times are rounded off upto 2 decimal places
*/



Q4) =>

Sample text files used are attached in the zip names are
input.txt(empty), output.txt(empty), sample0.txt, sample1.txt, sample2.txt, sample3.txt		

# Result :

Command to Run the script :  $ bash Q4.sh sample0.txt 2

Output: 

# Subtask1 :

# Frequency of all words in file sample0.txt
# WORD -> COUNT
# cute -> 1
# caat -> 1
# bat -> 1
# dog -> 3
# cat -> 3
# rohit -> 1
# mat -> 1
# pandya -> 1
# verma -> 1
# kohli -> 1
# root -> 3

# FILENAME -> COUNT_OF_MASKED
# input.txt -> 0
# output.txt -> 0
# sample0.txt -> 9
# sample1.txt -> 6
# sample2.txt -> 4
# sample3.txt -> 5

# Subtask2 : 

# Files in descending order of 'MASKED' count are as follows: 
# FILENAME -> COUNT_OF_MASKED
# sample0.txt -> 9
# sample1.txt -> 6
# sample3.txt -> 5
# sample2.txt -> 4


