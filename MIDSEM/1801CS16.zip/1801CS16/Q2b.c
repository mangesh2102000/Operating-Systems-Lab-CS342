/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - MID SEM EXAM 2021
FileName : Q2b.c 
Problem Statement : Matrix Properties Example.
  Thread 1 will check Commutative Law and prints the output as “Commutative"
  Thread 2 will check Associative Law and prints the output as “Associative”
  Thread 3 will check Additive Identity and prints the Additive Identity Matrix as output
  Thread 4 will check Additive Inverse and prints the Additive Inverse Matrix as output
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h> 
#include <math.h> 

#define MAX_THREADS 4
#define MAX_SIZE 1005

typedef void* address_t;
int A[MAX_SIZE][MAX_SIZE], B[MAX_SIZE][MAX_SIZE], C[MAX_SIZE][MAX_SIZE];
int status;
int rows[3],cols[3];

void print_matrix(int* Matrix,int rows,int cols){

	for(int i=0;i<rows;i++){
		for(int j=0;j<cols;j++){
			printf("%d ", *((Matrix+i*cols)+j) );
		}
		printf("\n");
	}
	printf("\n");
}

void* check_commutative(address_t args)
{
	printf("Output from Thread 1 (Thread ID : 0x%lx) \n",pthread_self());
	if(rows[0] == rows[1] && cols[0] == cols[1]){

		printf("Matrix A + B : \n");
		for(int i=0;i<rows[0];i++){
			for(int j=0;j<cols[0];j++){
				printf("%d ",A[i][j] + B[i][j]);
			}
			printf("\n");
		}
		printf("\n");

		printf("Matrix B + A : \n");
		for(int i=0;i<rows[0];i++){
			for(int j=0;j<cols[0];j++){
				printf("%d ",B[i][j] + A[i][j]);
			}
			printf("\n");
		}
		printf("\n");

		printf("\nAs A and B are matrices of same order %d x %d => A + B = B + A i.e. Commutaive\n", rows[0], cols[0]);
	}
	else{
		printf("\nAs A and B are matrices of different order A(%d x %d), B(%d x %d) => A + B and B + A is undefined i.e. Not Commutaive\n", rows[0], cols[0], rows[1], cols[1]);
	}
}

void* check_associative(address_t args)
{
	printf("\nOutput from Thread 2 (Thread ID : 0x%lx) \n", pthread_self());

	if( rows[0] == rows[1] && rows[1] == rows[2] && cols[0] == cols[1] && cols[1] == cols[2] ){
		
		printf("Matrix A + B : \n");
		for(int i=0;i<rows[0];i++){
			for(int j=0;j<cols[0];j++){
				printf("%d ",A[i][j] + B[i][j]);
			}
			printf("\n");
		}
		printf("\n");

		printf("Matrix (A + B) + C: \n");
		for(int i=0;i<rows[0];i++){
			for(int j=0;j<cols[0];j++){
				printf("%d ",A[i][j] + B[i][j] + C[i][j]);
			}
			printf("\n");
		}
		printf("\n");

		printf("Matrix B + C : \n");
		for(int i=0;i<rows[0];i++){
			for(int j=0;j<cols[0];j++){
				printf("%d ",B[i][j] + C[i][j]);
			}
			printf("\n");
		}
		printf("\n");

		printf("Matrix A + (B + C): \n");
		for(int i=0;i<rows[0];i++){
			for(int j=0;j<cols[0];j++){
				printf("%d ",A[i][j] + B[i][j] + C[i][j]);
			}
			printf("\n");
		}
		printf("\n");

		printf("\nAs A, B, C are matrices of same order %d x %d => (A + B) + C = A + (B + C) i.e. Associative\n", rows[0], cols[0]);
	}
	else{
		printf("\nAs A, B, C are matrices of different order (not all have same order) A(%d x %d), B(%d x %d), C(%d x %d) => (A + B) + C  and A + (B + C) is undefined i.e. Not Associative\n", rows[0], cols[0], rows[1], cols[1], rows[2], cols[2]);
		
	}
}

void* print_additive_identity(address_t args)
{
	printf("\nOutput from Thread 3 (Thread ID : 0x%lx) \n", pthread_self());

	printf("\nAdditive Identity for Matrix A : \n");
	for(int i=0;i<rows[0];i++){
		for(int j=0;j<cols[0];j++){
			printf("0 ");
		}
		printf("\n");
	}
	printf("\n");

	printf("\nVerification A + O = O + A = A : \n");
	for(int i=0;i<rows[0];i++){
		for(int j=0;j<cols[0];j++){
			printf("%d ",A[i][j] + 0);
		}
		printf("\n");
	}
	printf("\n");
}

void* print_additive_inverse(address_t args)
{
	printf("\nOutput from Thread 4 (Thread ID : 0x%lx) \n", pthread_self());

	printf("\nAdditive Inverse for Matrix A : \n");
	for(int i=0;i<rows[0];i++){
		for(int j=0;j<cols[0];j++){
			printf("%d ",(-1) * A[i][j]);
		}
		printf("\n");
	}
	printf("\n");

	printf("\nVerification A + (-A) = O : \n");
	for(int i=0;i<rows[0];i++){
		for(int j=0;j<cols[0];j++){
			printf("%d ",(-1) * A[i][j] + A[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

int main(int argc, char *argv[])
{
	printf("\nEnter dimension for Matrix A (Format: num_rows num_cols) : ");
	scanf("%d %d",&rows[0],&cols[0]);

	printf("Enter elements for Matrix A (Format:\n[ A(0,0) A(0,1) .. A(0,num_cols-1)\n  A(1,0) A(1,1) .. A(1,num_cols-1)\n  ....\n  A(num_rows-1,0) A(num_rows-1,1) .. A(num_rows-1,num_cols-1) ] )\n");
	for(int i=0;i<rows[0];i++){
		for(int j=0;j<cols[0];j++){
			scanf("%d",&A[i][j]);
		}
	}
	printf("\n");

	printf("Enter dimension for Matrix B (Format: num_rows num_cols) : ");
	scanf("%d %d",&rows[1],&cols[1]);

	printf("Enter elements for Matrix B (Format:\n[ B(0,0) B(0,1) .. B(0,num_cols-1)\n  B(1,0) B(1,1) .. B(1,num_cols-1)\n  ....\n  B(num_rows-1,0) B(num_rows-1,1) .. B(num_rows-1,num_cols-1) ] )\n");
	for(int i=0;i<rows[1];i++){
		for(int j=0;j<cols[1];j++){
			scanf("%d",&B[i][j]);
		}
	}
	printf("\n");

	printf("Enter dimension for Matrix C (Format: num_rows num_cols) : ");
	scanf("%d %d",&rows[2],&cols[2]);

	printf("Enter elements for Matrix C (Format:\n[ C(0,0) C(0,1) .. C(0,num_cols-1)\n  C(1,0) C(1,1) .. C(1,num_cols-1)\n  ....\n  C(num_rows-1,0) C(num_rows-1,1) .. C(num_rows-1,num_cols-1) ] )\n");
	for(int i=0;i<rows[2];i++){
		for(int j=0;j<cols[2];j++){
			scanf("%d",&C[i][j]);
		}
	}
	printf("\n");

	// printf("Printing Matrix A : \n");
	// print_matrix(&A[0][0], rows[0], cols[0]);
	
	// printf("Printing Matrix B : \n");
	// print_matrix(&B[0][0], rows[1], cols[1]);

	// printf("Printing Matrix C : \n");
	// print_matrix(&C[0][0], rows[2], cols[2]);


	// Declare required variables for a thread
	pthread_t threadID[MAX_THREADS];
	address_t statusp;

	// Create threads
	status = pthread_create(&threadID[0], NULL, check_commutative, NULL);
	status = pthread_create(&threadID[1], NULL, check_associative, NULL);
	status = pthread_create(&threadID[2], NULL, print_additive_identity, NULL);
	status = pthread_create(&threadID[3], NULL, print_additive_inverse, NULL);
	

	for(int i=0;i<4;i++){
		pthread_join(threadID[i], &statusp);
	}

	return 0;
}
