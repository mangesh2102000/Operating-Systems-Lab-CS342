#!/bin/bash

#Name : Chandrawanshi Mangesh Shivaji
#Roll Number : 1801CS16
#CS342 Lab - MID SEM EXAM 2021
#FileName : Q4.sh 

# Take FILENAME and K Input from Command Line Argument
fileName=$1
K=$2
divisor=2

#Subtask 1:
# Iterate over every wword from input file and store frequency
declare -A word_freq

while IFS= read -r CURR_LINE || [[ -n "$CURR_LINE" ]]
do
	for CURR_WORD in $CURR_LINE
	do
		let word_freq[$CURR_WORD]=${word_freq[$CURR_WORD]}+1
	done
done < $fileName

# Store all words with frequency greater than K 
declare -A words_to_change
idx1=0
printf "Subtask1 :\n\nFrequency of all words in file %s\n" "$fileName"
printf "%s -> %s\n" "WORD" "COUNT"
for idx in "${!word_freq[@]}"
do
	printf "%s -> %s\n" "$idx" "${word_freq[$idx]}"
	if [[ "word_freq[$idx]" -gt "${K}" ]]
	then
		words_to_change[${idx1}]=$idx
		((idx1++))
	fi
done
printf "\n"

# Now we have to mask all the words_to_change in all .txt files in current directory
declare -A mask_freq
declare -A files_directory
idx2=0
printf "%s -> %s\n" "FILENAME" "COUNT_OF_MASKED"
for CURR_FILE in `ls *.txt`
do 
	for CURR_WORD in "${words_to_change[@]}"
	do
		sed -i "s/$CURR_WORD/MASKED/g" "$CURR_FILE"
	done

	files_directory[${idx2}]=$CURR_FILE
	mask_freq[${idx2}]=$(grep -o -i MASKED $CURR_FILE | wc -l)

	printf "%s -> %s\n" "$CURR_FILE" "${mask_freq[$idx2]}"
	((idx2++))
done

#Subtask2:
# Sort All the files in descending count of 'MASKED', should contain atleast (K/2)
# bubble sort is used
printf "\nSubtask2 : \n\n"
printf "Files in descending order of 'MASKED' count are as follows: \n"
for itr1 in "${!mask_freq[@]}"
do
	for itr2 in "${!mask_freq[@]}"
	do 
		if [[ ${mask_freq[$itr1]} -gt ${mask_freq[$itr2]} ]]
		then
			temp_mask_freq=${mask_freq[$itr1]}
			mask_freq[$itr1]=${mask_freq[$itr2]}
			mask_freq[$itr2]=${temp_mask_freq}

			temp_files_directory=${files_directory[$itr1]}
			files_directory[$itr1]=${files_directory[$itr2]}
			files_directory[$itr2]=${temp_files_directory}
		fi
	done
done 

# Print files in descending order of 'MASKED' freq.
printf "%s -> %s\n" "FILENAME" "COUNT_OF_MASKED"
for idx in "${!files_directory[@]}"
do
	if [[ $((K / divisor)) -lt ${mask_freq[$idx]} ]]
	then
		printf "%s -> %s\n" "${files_directory[$idx]}" "${mask_freq[$idx]}"
	fi
done 

