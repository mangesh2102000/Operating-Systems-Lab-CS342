/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - MID SEM EXAM 2021
FileName : Q2a.c 
Problem Statement : Alternating Harmonic Series Example.
  Child 1 should compute the sum of negative numbers in the series
  Child 2 should compute the sum of positive prime numbers in the series
  Child 3 should compute the sum of positive non-prime numbers in the series
  Parent process should print the final result of the series.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h> 

// function to check prime numbers 
int is_prime(int x)
{
	if(x <= 1)
		return 0;

	for(int i=2;i*i<=x;i++)
	{
		if(x%i == 0)
			return 0;
	}

	return 1;
}

int main(int argc, char *argv[])
{
	if(argc != 2)
	{
		printf("Invalid arguments, Usage : ./Q2a n; where n is any positive integer.\n");
		return 0;
	}

	int n = atoi(argv[1]);

	/* Create Pipeline to transfer/recieve value between processes */
	int fd1[2]; /* fd1[0] - read and fd1[1] - write */
	pipe(fd1);

	pid_t pid = fork();

	// Check if valid child is created or not 
	if(pid < 0)	{
		printf("Can't fork!\n");
		exit(1);
	}

	if( pid > 0 ) {
		// parent process
		wait(NULL);
		double sum=0;
		read(fd1[0],&sum,sizeof(double));
		printf("Parent Process ID : %d, Final Result of the series i.e. sum of all numbers : %.6lf\n\n", getpid(), sum);

	} else if( pid == 0 ) {

		/* Create Pipeline to transfer/recieve value between processes */
		int fd2[2]; /* fd2[0] - read and fd2[1] - write */
		pipe(fd2);

		pid = fork();

		if( pid > 0 ){
			//child 1 process
			wait(NULL);
			double sum1 = 0;
			for(int i=1;i<=n;i++){
				if(i%2 == 0){
					sum1 += (-1/(double)i);
				}
			}
			printf("Child 1 Process ID : %d, Computed sum of negative numbers in the series : %.6lf\n", getpid(), sum1);		

			double sum=0;
			read(fd2[0],&sum,sizeof(double));
			sum += sum1;
			write(fd1[1],&sum,sizeof(double));

		} else if (pid == 0){

			/* Create Pipeline to transfer/recieve value between processes */
			int fd3[2]; /* fd3[0] - read and fd3[1] - write */
			pipe(fd3);

			pid = fork();

			if( pid > 0 ){
				//child 2 process
				wait(NULL);
				double sum2 = 0;
				for(int i=1;i<=n;i++){
					if(i%2 == 1 && is_prime(i)){
						sum2 += (1/(double)i);
					}
				}
				printf("Child 2 Process ID : %d, Computed sum of positive prime nubers in the series : %.6lf\n", getpid(), sum2);		
				
				double sum=0;
				read(fd3[0],&sum,sizeof(double));
				sum += sum2;
				write(fd2[1],&sum,sizeof(double));
			}
			else if (pid == 0){

				double sum3 = 0;
				for(int i=1;i<=n;i++){
					if(i%2 == 1 && !is_prime(i)){
						sum3 += (1/(double)i);
					}
				}
				printf("\nChild 3 Process ID : %d, Computed sum of positive non-prime nubers in the series : %.6lf\n", getpid(), sum3);		
				
				double sum=sum3;
				write(fd3[1],&sum,sizeof(double));
			}
		}
	}
}
