/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - MID SEM EXAM 2021
FileName : Q1.c 
Problem Statement : Program o execute the zombie and orphan process in a single program */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h> 

int main(int argc, char *argv[])
{
	pid_t pid = fork();

	if( pid < 0 ) {
		printf("Process Creation Failed!\n");
		exit(1);
	}

	if( pid > 0 ) {
		// parent process
		printf("Parent Process ID : %d\n", getpid());

	} else if( pid == 0 ) {

		//child process
		sleep(10);	// Due to this, child process becomes a Orphan Process for some time before it is adopted by init process

		printf("\nOrphan Process : ");
		printf("\nChild Process ID : %d, Parent Process ID : %d\n",getpid(),getppid());
		printf("Note the change in Parent Process ID of Child Process %d\n", getpid());

		pid = fork();

		if( pid > 0 ) {

			// parent process
			sleep(20);			// Due to this, child process becomes a Zombie Process for about 20 seconds
	
		} else if( pid == 0) {

			printf("\nZombie Process : ");
			printf("\nChild Process ID : %d, Parent Process ID : %d\n",getpid(),getppid());
		}
	}
}
