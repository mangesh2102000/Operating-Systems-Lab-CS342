Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
Operating Systems Lab (CS342) Assignment1
FileName : README.txt

Please make sure you are in the same folder as script file while execution

script file names script1.sh, script2.sh, script3.sh, script4.sh for respective questions 

#1 Write a shell script to print a given Number in reverse order such that the input is provided using 
commandLineArgument only. If the input data is not provided as a Command Line Argument, it should throw an error. 

-> Commands to execute script1.sh along with output for few test examples (after making the script executable)

$ chmod u+x script1.sh 

$ ./script1.sh -1568
Input : -1568  Output : -8651

$ ./script1.sh 001
Input : 001  Output : 100

$ ./script1.sh 1056850
Input : 1056850  Output : 0586501

$ ./script1.sh
Error: Input Data is not provided as Command Line Argument

Note : It is assumed that for negative numbers only numerical part is to be reversed


#2 Write a simple shell script that takes two numbers as parameters and uses a while loop to print all the numbers from the 
first to the second inclusive, each number separated only by a space from the previous number.

-> Commands to execute script2.sh along with output for few test examples (after making the script executable)

$ chmod u+x script2.sh 

$ ./script2.sh 1 5
Input : NUMBER1 = 1 NUMBER2 = 5
Output :  1 2 3 4 5

$ ./script2.sh 1 0
Input : NUMBER1 = 1 NUMBER2 = 0
Error: For usage : ./script2.sh NUMBER1 NUMBER2, NUMBER2 should be >= NUMBER1

$ ./script2.sh 1 1 3
Error: Input Data provided is not valid, usage : ./script2.sh NUMBER1 NUMBER2

$ ./script2.sh -5 12
Input : NUMBER1 = -5 NUMBER2 = 12
Output :  -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 11 12

#3 Write a shell script to simply count the number of lines in an input file by iterating over all lines. 
If the number of lines is less than a value then delete the file. The inputs are provided using command Line Argument only

-> Commands to execute script3.sh along with output for few test examples (after making the script executable)
// abc.txt is provided in the zip

$ chmod u+x script3.sh 

$ ./script3.sh abc.txt 10
The number of lines in the given file is: 26

// Here, as 26 is greater than 10, file is still there

$ ./script3.sh abc.txt 30
The number of lines in the given file is: 26

// Now, file must be deleted as 26 < 30 and following execution proves it also

$ ./script3.sh abc.txt 20
Error: abc.txt no such file exists


#4 Write a shell script to take a ​​directory_path​, a​​ filename_pattern and a ​​new_filename as input. Rename all files in directory which matches ​filename_pattern to {​new_filename​}_{​count​}​.txt

-> Commands to execute script4.sh along with output for few test examples (after making the script executable)
// Folder named "check" contains empty files used in test example (provided in the zip) 
// Output contains all the modified filenames serially

$ chmod u+x script4.sh 

$ ./script4.sh ./check aa abc
abc_1.txt
abc_2.txt
abc_3.txt
abc_4.xuz
abc_5.xyz

$ ./script4.sh ./check bc new
new_1.txt
new_2.txt
new_3.txt
new_4.xuz
new_5.xyz

$ ./script4.sh ./check bc
Error: Input Data provided is not valid, usage : ./script3.sh ​​directory_path​ filename_pattern new_filename 
