#!/bin/bash

#Name : Chandrawanshi Mangesh Shivaji
#Roll Number : 1801CS16
#FileName : script1.sh


if [ $# -eq 0 ]
then 
	echo "Error: Input Data is not provided as Command Line Argument"
else

	#Declaration of required variables 
	NUMBER=$1
	LEN=${#NUMBER}
	RESULT=""
	i=0
	pos=1

	#Check if NUMBER is negative or not
	if [ "${NUMBER:i:1}" == "-" ]
	then 
		pos=0
		((i++))
	fi 

	#Loop to reverse the number
	while [ $i -lt $LEN ]
	do
		RESULT="${NUMBER:i++:1}$RESULT"
	done

	#Prepend - to RESULT in case of negative numbers
	if [ $pos == 0 ]
	then
		RESULT="-$RESULT"
	fi

	#Final RESULT
	echo "Input : $NUMBER  Output : $RESULT"
fi			