#!/bin/bash

#Name : Chandrawanshi Mangesh Shivaji
#Roll Number : 1801CS16
#FileName : script2.sh


if [ $# != 2 ]
then 
	echo "Error: Input Data provided is not valid, usage : ./script2.sh NUMBER1 NUMBER2 "
else

	#Declaration of required variables 
	NUMBER1=$1
	NUMBER2=$2
	RESULT=""

	#Input
	echo "Input : NUMBER1 = $NUMBER1 NUMBER2 = $NUMBER2"

	#Check Validity of Input
	if [ $NUMBER2 -lt $NUMBER1 ]
	then 
		echo "Error: For usage : ./script2.sh NUMBER1 NUMBER2, NUMBER2 should be >= NUMBER1"
	else

		#Iterate from NUMBER1 to NUMBER2
		i=$NUMBER1

		while [ $i -le $NUMBER2 ]
		do
			RESULT="$RESULT $i"
			((i++))
		done

		#Output RESULT
		echo "Output : ${RESULT[@]}"
	fi
fi			