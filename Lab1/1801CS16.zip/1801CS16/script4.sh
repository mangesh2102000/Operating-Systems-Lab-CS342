#!/bin/bash

#Name : Chandrawanshi Mangesh Shivaji
#Roll Number : 1801CS16
#FileName : script4.sh

if [ $# != 3 ]
then 
	echo "Error: Input Data provided is not valid, usage : ./script3.sh ​​directory_path​ filename_pattern new_filename "
else

	#Declaration of required variables 
	directory_path=$1
	filename_pattern=$2
	new_filename=$3

	# Store Number of file matches
	cnt_of_matches=0

	# For each file in directory
	for file in "$directory_path"/*
	do
		#Store lengths of current file and pattern to be matched
		curr_filename_len=${#file}
		pattern_len=${#filename_pattern}

		# Try to match pattern with each substring of same length
		for i in $(seq 0 $curr_filename_len)
		do
			if [[ "${file:i:$pattern_len}" == "$filename_pattern" ]]
			then
				base="$(basename $file)"
			 	extension=${base##*.}

			 	#Increment Match Count 
				((cnt_of_matches++))

				#Modify FileName Accordingly
				modified_name="$3_$cnt_of_matches.$extension"
				echo "$modified_name"
				mv $file "$directory_path/$modified_name"

				#As only one match is enough
				break
			fi
		done
	done
fi			