#!/bin/bash

#Name : Chandrawanshi Mangesh Shivaji
#Roll Number : 1801CS16
#FileName : script3.sh


if [ $# != 2 ]
then 
	echo "Error: Input Data provided is not valid, usage : ./script3.sh fileName value "
else

	#Declaration of required variables 
	fileName=$1
	value=$2

	#Check if File exists or not
	if [ -e $fileName ]
	then
		#Check if file is readable or not
		if [ -r $fileName ]
		then

			lineCount=0
			EOF=0

			#Iterate over each line of file and increment lineCount
			while [ $EOF == 0 ]
			do 
				read -r line
				EOF=$?
				((lineCount++))
			done <$fileName

			echo "The number of lines in the given file is: $lineCount"

			#If lineCount is less than given value, delete the file
			if [ $lineCount -lt $value ]
			then
				rm $fileName
			fi

		else
			echo "Error: $fileName is not readable"
		fi
	else
		echo "Error: $fileName no such file exists"
	fi
fi			