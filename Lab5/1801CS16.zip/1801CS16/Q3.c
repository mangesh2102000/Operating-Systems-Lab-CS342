/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 5
FileName : Q3.c 
Problem Statement : Write a program that computes the cube roots of the integers from 0 to 999 in a 
separate thread and returns an array of doubles containing the results. In the meantime, the main 
thread should display a short message “Computation under process. Please wait ...” to the user and 
then display the results of the computation when they are ready. For example: cbrt (0) = 0.000000 */

#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h> 
#include <pthread.h> 
#include <math.h>

typedef void * address_t;

void * thread_func_to_calc_cbrt(address_t args)
{
	// double array to store cube root values
	double *values = malloc(sizeof(double)*1000);

	// Computation .. 
	for(int i=0;i<1000;i++)
	{
		values[i] = cbrt((double)i);
	}

	// return the obtained values

	pthread_exit((address_t)values);
}

int main(void)
{
	// Declare required variables for a thread
	pthread_t threadID;
	address_t statusp;

	double* res;

	// Create thread using corresponding function
	int status = pthread_create(&threadID, NULL, thread_func_to_calc_cbrt, NULL);

	if(status != 0)
	{
		printf("Error Occured while creating thread\n");
		exit(1);
	}

	pthread_join(threadID, &statusp);

	printf("\nComputation under process. Please wait ...\n");

	// store return value (pointer to double array of cube roots)
	res = (double *) statusp;

	printf("\nPrinting Cube roots of 0 to 999 : \n");	

	for(int i=0;i<1000;i++)
	{
		printf("\ncbrt(%d) = %lf", i, res[i])	;
	}

	printf("\n\n");

	// free allocated memory
	free(res);
	return 0;
}




