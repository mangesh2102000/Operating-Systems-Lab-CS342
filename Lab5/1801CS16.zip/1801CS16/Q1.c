/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 5
FileName : Q1.c 
Problem Statement : Write a simple C program to create N threads (Ax = 50), and print required output*/

#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h> 
#include <pthread.h> 
#include <math.h>

#define MAX_THREADS 50

typedef void * address_t;

// Function to call for each thread
void * threadFunction(address_t args)
{
	int *iter = (int *)args;

	if(*iter % 5 == 0)
		sleep(5);
	else
		sleep(*iter % 5);

	printf("Hello from groot (Thread ID : 0x%lx)- I was created in iteration %d\n", pthread_self(), *iter);

	pthread_exit((address_t) NULL);
}

int main(int argc, char const *argv[])
{
	// Check for Invalid Input
	if(argc != 2)
	{
		printf("\nInvalid Input!; Usage: ./Q1 N\nwhere N is number of threads to be created, Max allowed value of N is 50\n");
		exit(1);
	}

	int N = atoi(argv[1]);

	if(N > 50)
	{
		printf("\nInvalid Input!; Usage: ./Q1 N\nwhere N is number of threads to be created, Max allowed value of N is 50\n");
		exit(1);
	}

	printf("\n");

	pthread_t threadID[N];
	address_t statusp;

	int itertion[N];

	// Create Threads and Print Output Accordingly
	for(int i=1;i<N+1;i++)
	{
		itertion[i] = i;
		int status = pthread_create(&threadID[i], NULL, threadFunction, (address_t) &itertion[i]);
		if(status != 0)
		{
			printf("Error Occured while creating thread\n");
			exit(1);
		}
		printf("I am groot (Thread ID : 0x%lx). Created new groot (Thread ID : 0x%lx) in iteration %d...\n", pthread_self(), threadID[i], i);

		if(i%5==0)
			sleep(6);
	}

	printf("\n");

    // Join Threads
	for(int i=1;i<N+1;i++)
	{
    	pthread_join(threadID[i], &statusp);
    }

	return 0;
}