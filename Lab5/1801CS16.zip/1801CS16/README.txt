Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
Operating Systems Lab (CS342) Assignment5
FileName : README.txt

Please make sure you are in the same folder as .c files

.c file names Q1.c, Q2.c, Q3.c for respective questions 

#1 
-> Commands to execute Q1.c along with output explanation

$ gcc -o Q1 Q1.c -lm -pthread
$ ./Q1 N (N should be less than equal to 50)

test sample : ./Q1 15 
result :

I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37f3142640) in iteration 1...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37f2941640) in iteration 2...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37f2140640) in iteration 3...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37f193f640) in iteration 4...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37f113e640) in iteration 5...
Hello from groot (Thread ID : 0x7f37f3142640)- I was created in iteration 1
Hello from groot (Thread ID : 0x7f37f2941640)- I was created in iteration 2
Hello from groot (Thread ID : 0x7f37f2140640)- I was created in iteration 3
Hello from groot (Thread ID : 0x7f37f193f640)- I was created in iteration 4
Hello from groot (Thread ID : 0x7f37f113e640)- I was created in iteration 5
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37f0922640) in iteration 6...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37ebfff640) in iteration 7...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37eb7fe640) in iteration 8...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37eaffd640) in iteration 9...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37ea7fc640) in iteration 10...
Hello from groot (Thread ID : 0x7f37f0922640)- I was created in iteration 6
Hello from groot (Thread ID : 0x7f37ebfff640)- I was created in iteration 7
Hello from groot (Thread ID : 0x7f37eb7fe640)- I was created in iteration 8
Hello from groot (Thread ID : 0x7f37eaffd640)- I was created in iteration 9
Hello from groot (Thread ID : 0x7f37ea7fc640)- I was created in iteration 10
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37e9ffb640) in iteration 11...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37e97fa640) in iteration 12...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37e8ff9640) in iteration 13...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37e87f8640) in iteration 14...
I am groot (Thread ID : 0x7f37f3143740). Created new groot (Thread ID : 0x7f37e7ff7640) in iteration 15...
Hello from groot (Thread ID : 0x7f37e9ffb640)- I was created in iteration 11
Hello from groot (Thread ID : 0x7f37e97fa640)- I was created in iteration 12
Hello from groot (Thread ID : 0x7f37e8ff9640)- I was created in iteration 13
Hello from groot (Thread ID : 0x7f37e87f8640)- I was created in iteration 14
Hello from groot (Thread ID : 0x7f37e7ff7640)- I was created in iteration 15


#2 
-> Commands to execute Q2.c along with output explanation 

$  gcc -o Q2 Q2.c -lm -pthread

$ ./Q2

test sample : ./Q2
result:

After execution of all 10 threads => 

Final Value of local static variable : 10
Final Value of global variable : 10


#3 
-> Commands to execute Q3.c along with output

$ gcc -o Q3 Q3.c -lm -pthread

$ ./Q3

test sample : ./Q3
result:

Computation under process. Please wait ...

Printing Cube roots of 0 to 999 : 

cbrt(0) = 0.000000
cbrt(1) = 1.000000
cbrt(2) = 1.259921
cbrt(3) = 1.442250
cbrt(4) = 1.587401
cbrt(5) = 1.709976
.
.
.
.
.
cbrt(996) = 9.986649
cbrt(997) = 9.989990
cbrt(998) = 9.993329
cbrt(999) = 9.996666
