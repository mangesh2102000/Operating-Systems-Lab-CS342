/* Name : Chandrawanshi Mangesh Shivaji 
Roll Number : 1801CS16
CS342 Lab - Assignment 5
FileName : Q2.c 
Problem Statement : Write a simple C program to creates 10 threads (each thread increments the
variable by one). Define two variables, global (shared among all threads) and
local static and wait for all threads to complete its execution, then show the final
value of each variable */

#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h> 
#include <pthread.h> 
#include <math.h>

#define NUM_THREADS 10

typedef void * address_t;

// global variable
int global_var = 0;

void * increment_func(address_t args)
{
	// local static variable
	static int static_var = 0;

	// increment both global and local static variables
	++static_var;
	++global_var;

	pthread_exit((address_t)&static_var);
}

int main(void)
{
	pthread_t threadID[NUM_THREADS];
	address_t statusp;

	for(int i=0;i<10;i++)
	{
		int status = pthread_create(&threadID[i], NULL, increment_func, NULL);

		if(status != 0)
		{
			printf("Error Occured while creating thread\n");
			exit(1);
		}
		
		pthread_join(threadID[i], &statusp);
	}

	// store returned value after execution of last (10th thread) of static vaiable to print
	int return_value = (*((int *)statusp));

	printf("\nAfter execution of all 10 threads => \n");

	printf("\nFinal Value of local static variable : %d\nFinal Value of global variable : %d\n\n", return_value, global_var);

	return 0;
}